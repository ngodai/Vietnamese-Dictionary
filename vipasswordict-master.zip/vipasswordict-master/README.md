vipasswordict
=============

Vietnamese Password Dicts

Password Dict Collections for Vietnamese Language

Creator: xnohat
Email: xnohat@gmail.com
http://www.hvaonline.net